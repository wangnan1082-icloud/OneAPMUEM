//
//  testviewTests.m
//  OneAPMDemoTest
//
//  Created by JunLee on 15/12/16.
//  Copyright © 2015年 Jun Li. All rights reserved.
//
#import "OCMock.h"

#import <XCTest/XCTest.h>
#import "testview.h"

@interface testviewTests : XCTestCase

@property (nonatomic,strong)testview *coreDataControllerView;
@property (nonatomic,strong)AppDelegate *mydelegate;
@end

@implementation testviewTests

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
    self.coreDataControllerView = [[testview alloc] init];
    
    
    
    
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    self.coreDataControllerView = nil;
    [super tearDown];
}

- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
    
    

}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

-(void)testsaveTests{
    
//     NSManagedObject *object=[NSEntityDescription insertNewObjectForEntityForName:@"Province" inManagedObjectContext:self.mydelegate.managedObjectContext];
//    
//    id objectMock = OCMStrictClassMock([NSManagedObject class]);
//    OCMStub([objectMock goFaster:[OCMArg any] units:@"kph"]).andReturn(@"75kph");
//    
////    id objectMock = OCMClassMock([NSManagedObject class]);
////    OCMStub([NSEntityDescription insertNewObjectForEntityForName:@"Province" inManagedObjectContext:self.coreDataControllerView.mydelegate.managedObjectContext]).andReturn(objectMock);
//    OCMClassMock([NSManagedObject class]);
//    self.coreDataControllerView.citytext.text = @"Harbin";
//    self.coreDataControllerView.provincetext.text = @"Heilongjiang";
//    
//    [self.coreDataControllerView save:nil];
    
}

@end
