//
//  OneAPMDemoTestTests.m
//  OneAPMDemoTestTests
//
//  Created by JunLee on 15/12/14.
//  Copyright © 2015年 Jun Li. All rights reserved.
//

#import <XCTest/XCTest.h>
//#import "GlobalTimelineViewController.h"
@interface OneAPMDemoTestTests : XCTestCase
@property (nonatomic,strong)NSArray *testArray;
@end

@implementation OneAPMDemoTestTests

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
    
    // 1.创建Table View的DataSource

}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

- (void)testNumberOfRows {
    // 1.创建Table View的DataSource
//    TableViewCellConfigureBlock cellConfigureBlock = ^(UITableViewCell *cell, NSString *item) {
//        cell.textLabel.text = item;
//    };
//    GlobalTimelineViewController * vC = [[GlobalTimelineViewController alloc] init];
//    self.testArray = @[@"1", @"2", @"3"];
    
    
    // 2.创建mock table view
//    id mockTableView = [OCMockObject mockForClass:[UITableView class]];
//    [mockTableView tableView:mockTableView didSelectRowAtIndexPath: ]
    
    // 3.断言
//    XCTAssertEqual([vC tableView:mockTableView numberOfRowsInSection:0], (NSInteger)3, @"Mock table returns a bad number of rows in section 0");
}

@end
