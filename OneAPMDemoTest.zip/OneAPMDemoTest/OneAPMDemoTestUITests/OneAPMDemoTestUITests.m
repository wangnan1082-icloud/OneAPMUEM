//
//  OneAPMDemoTestUITests.m
//  OneAPMDemoTestUITests
//
//  Created by JunLee on 15/12/14.
//  Copyright © 2015年 Jun Li. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface OneAPMDemoTestUITests : XCTestCase

@end

@implementation OneAPMDemoTestUITests

- (void)setUp {
    [super setUp];
    
    // Put setup code here. This method is called before the invocation of each test method in the class.
    
    // In UI tests it is usually best to stop immediately when a failure occurs.
    self.continueAfterFailure = NO;
    // UI tests must launch the application that they test. Doing this in setup will make sure it happens for each test method.
    
    [[[XCUIApplication alloc] init] launch];
    
    // In UI tests it’s important to set the initial state - such as interface orientation - required for your tests before they run. The setUp method is a good place to do this.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testSDWebImage {
    [XCUIDevice sharedDevice].orientation = UIDeviceOrientationPortrait;
    
    XCUIApplication *app = [[XCUIApplication alloc] init];
    
    [[[[[app.otherElements containingType:XCUIElementTypeNavigationBar identifier:@"View"] childrenMatchingType:XCUIElementTypeOther].element childrenMatchingType:XCUIElementTypeOther].element childrenMatchingType:XCUIElementTypeOther].element tap];
    
    [app.buttons[@"SDImage"] tap];
    
    XCUIElementQuery *tablesQuery = app.tables;
    XCUIElement *image0StaticText = tablesQuery.staticTexts[@"Image #0"];
    [image0StaticText tap];
    
    XCUIElement *sdwebimageButton = app.navigationBars[@"DetailView"].buttons[@"SDWebImage"];
    [sdwebimageButton tap];
    
    XCUIElement *image1StaticText = tablesQuery.staticTexts[@"Image #1"];
    [image1StaticText tap];
    [sdwebimageButton tap];
    
    XCUIElement *image2StaticText = tablesQuery.staticTexts[@"Image #2"];
    [image2StaticText tap];
    [sdwebimageButton tap];
    
    XCUIElement *image3StaticText = tablesQuery.staticTexts[@"Image #3"];
    [image3StaticText tap];
    [sdwebimageButton tap];
    
    XCUIElement *image4StaticText = tablesQuery.staticTexts[@"Image #4"];
    [image4StaticText tap];
    [sdwebimageButton tap];
    
    XCUIElement *image5StaticText = tablesQuery.staticTexts[@"Image #5"];
    [image5StaticText tap];
    [sdwebimageButton tap];
    [app.navigationBars[@"SDWebImage"].buttons[@"Clear Cache"] tap];
    [image0StaticText tap];
    [sdwebimageButton tap];
    [image1StaticText tap];
    [sdwebimageButton tap];
    [image2StaticText tap];
    [sdwebimageButton tap];
    [image3StaticText tap];
    [sdwebimageButton tap];
    [image4StaticText tap];
    [sdwebimageButton tap];
    [image5StaticText tap];
    [sdwebimageButton tap];
}

- (void)testJson {
    
    XCUIApplication *app = [[XCUIApplication alloc] init];
    [[[[[app.otherElements containingType:XCUIElementTypeNavigationBar identifier:@"View"] childrenMatchingType:XCUIElementTypeOther].element childrenMatchingType:XCUIElementTypeOther].element childrenMatchingType:XCUIElementTypeOther].element tap];
    [app.buttons[@"Json"] tap];
    [app.buttons[@"NSURLConnection请求"] tap];
    [[[[app.navigationBars[@"JSONMethodsView"] childrenMatchingType:XCUIElementTypeButton] matchingIdentifier:@"Back"] elementBoundByIndex:0] tap];
    
}

@end
