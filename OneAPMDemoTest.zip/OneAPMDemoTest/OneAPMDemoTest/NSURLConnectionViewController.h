//
//  NSURLConnectionViewController.h
//  OneAPMDemo
//
//  Created by 李家龙 on 15/10/26.
//  Copyright © 2015年 李家龙. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NSURLConnectionViewController : UIViewController<NSURLConnectionDelegate,NSURLConnectionDataDelegate>
@property (weak, nonatomic) IBOutlet UITextField *postURLTF;
@property (weak, nonatomic) IBOutlet UITextField *GetURLTF;
- (IBAction)postAction:(id)sender;
- (IBAction)getAction:(id)sender;

@end
