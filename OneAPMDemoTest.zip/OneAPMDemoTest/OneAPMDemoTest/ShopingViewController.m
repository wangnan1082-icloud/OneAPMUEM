//
//  ShopingViewController.m
//  OneAPMDemoTest
//
//  Created by yuxr on 16/4/12.
//  Copyright © 2016年 Jun Li. All rights reserved.
//

#import "ShopingViewController.h"

@interface ShopingViewController ()
@property (weak, nonatomic) IBOutlet UITextField *goodsNameTF;
@property (weak, nonatomic) IBOutlet UITextField *buyNumberTF;
@property (weak, nonatomic) IBOutlet UIButton *typeABtn;
@property (weak, nonatomic) IBOutlet UIButton *typeBBtn;
@property (weak, nonatomic) IBOutlet UIButton *typeCBtn;

@end

@implementation ShopingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
//    [_typeABtn setTitleColor:[UIColor redColor] forState:UIControlStateSelected];
//    [_typeBBtn setTitleColor:[UIColor redColor] forState:UIControlStateSelected];
//    [_typeCBtn setTitleColor:[UIColor redColor] forState:UIControlStateSelected];
    
    [_typeABtn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    [_typeBBtn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    [_typeCBtn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
#ifdef KEnableActionAnalyticsTest
    // 进入行为分析页面
    [OneAPMActionAnalytics track:@"APM_ShopingVCDidLoad"];
#endif
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
#ifdef KEnableActionAnalyticsTest
    [OneAPMActionAnalytics track:@"APM_ShopingVCDidDisappear"];
#endif
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}
- (IBAction)buyBtnClick:(id)sender {
#ifdef KEnableActionAnalyticsTest
    // 设置购买商品的数量和名称
    [OneAPMActionAnalytics track:@"APM_buyGoods" withProperties:@{@"APM_goodsName" : _goodsNameTF.text,
                                                                  @"APM_goodsNumber" : _buyNumberTF.text}];
    
    NSNumber *currentTime = [NSNumber numberWithDouble:[[NSDate date] timeIntervalSince1970]];
    // 更新用户profile数据
    [OneAPMActionAnalytics set:@"APM_lastBuyTime" to:currentTime];
    [OneAPMActionAnalytics setOnce:@"APM_firstBuyTime" to:currentTime];
    [OneAPMActionAnalytics increment:@"APM_buyGoodsTotalNumber" by:[NSNumber numberWithInteger:[_buyNumberTF.text integerValue]]];
#endif
    NSMutableSet *mutSet = [[NSMutableSet alloc] init];
    if (_typeABtn.selected) {
        [mutSet addObject:@"typeA_goods"];
    }
    if (_typeBBtn.selected) {
        [mutSet addObject:@"typeB_goods"];
    }
    if (_typeCBtn.selected) {
        [mutSet addObject:@"typeC_goods"];
    }
#ifdef KEnableActionAnalyticsTest
    [OneAPMActionAnalytics append:@"APM_goodsType" by:mutSet];
#endif
}

- (void)btnClick:(id)sender {
    UIButton *btn = sender;
    btn.selected = !btn.selected;
}

@end
