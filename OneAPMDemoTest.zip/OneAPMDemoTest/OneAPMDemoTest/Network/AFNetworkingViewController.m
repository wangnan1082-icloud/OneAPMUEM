//
//  AFNetworkingViewController.m
//  OneAPMDemoTest
//
//  Created by 马杰亮 on 17/10/2017.
//  Copyright © 2017 Jun Li. All rights reserved.
//

#import "AFNetworkingViewController.h"
#import <AFNetworking/AFNetworking.h>

@interface AFNetworkingViewController ()
@property (weak, nonatomic) IBOutlet UITextView *textView;
@end

@implementation AFNetworkingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:configuration];
    NSSet *set = [NSSet setWithObject:@"text/html"];
    AFHTTPResponseSerializer *responseSerializer = [[AFHTTPResponseSerializer alloc] init];
    [responseSerializer setAcceptableContentTypes:set];
    manager.responseSerializer = responseSerializer;
    
    NSURL *URL = [NSURL URLWithString:@"https://www.baidu.com/"];
    NSURLRequest *request = [NSURLRequest requestWithURL:URL];
    __weak typeof(self) weakSelf = self;
    
    NSURLSessionDataTask *dataTask = [manager dataTaskWithRequest:request completionHandler:^(NSURLResponse *response, id responseObject, NSError *error) {
        NSString *string;
        if (error) {
            string = error.description;
        } else {
            string = [response.description stringByAppendingString:@"\n\n"];
            string = [string stringByAppendingString:[[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding]];
        }
        
        dispatch_async(dispatch_get_main_queue(), ^{
            weakSelf.textView.text = string;
        });
    }];
    [dataTask resume];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
