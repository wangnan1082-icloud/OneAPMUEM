//
//  NetMethodChooseViewController.m
//  OneAPMDemo
//
//  Created by JunLee on 15/11/17.
//  Copyright © 2015年 李家龙. All rights reserved.
//

#import "NetMethodChooseViewController.h"

#import "AALoginViewController.h"
#import "NSURLSessionTestViewController.h"

@interface NetMethodChooseViewController ()

@end

@implementation NetMethodChooseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)toURLSession:(id)sender {
    
    NSURLSessionTestViewController * sessionVc = [[NSURLSessionTestViewController alloc] initWithNibName:@"NSURLSessionTestViewController" bundle:nil];
    [self.navigationController pushViewController:sessionVc animated:YES];
}
- (IBAction)toAcmeAir:(id)sender {
    AALoginViewController * loginVC =[[AALoginViewController alloc] initWithNibName:@"AALoginViewController" bundle:nil];
    [self.navigationController pushViewController:loginVC animated:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (IBAction)testHttpError:(id)sender {
    //加载一个NSURL对象
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://www.oneapm.com/errorpage111"]];
    //将请求的url数据放到NSData对象中
    //    NSData *response = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    [request setValue:@"testHttpHeader" forHTTPHeaderField:@"OneAPMDemoTestHeader"];
    NSOperationQueue *queue = [[NSOperationQueue alloc]init];
    [NSURLConnection sendAsynchronousRequest:request
                                       queue:queue
                           completionHandler:^(NSURLResponse *response, NSData *data, NSError *error){
                               NSLog(@"OneAPMDemoTest make http error");
                               if (error) {
                                   NSLog(@"Httperror:%@%ld", error.localizedDescription,(long)error.code);
                               }else{
                                   //IOS5自带解析类NSJSONSerialization从response中解析出数据放到字典中
                                   NSDictionary *weatherDic __unused = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
                               }
                           }];

    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"http error" message:@"http://www.oneapm.com/errorpage111" delegate:nil cancelButtonTitle:@"取消" otherButtonTitles:nil];
    [alertView show];
    
}

@end
