//
//  WebView2ViewController.m
//  OneAPMDemoTest
//
//  Created by JunLee on 15/12/14.
//  Copyright © 2015年 Jun Li. All rights reserved.
//

#import "WebView2ViewController.h"
#import "WebViewTestContext.h"
#import "WKWebViewAdapter.h"
#import <Masonry.h>

@interface WebView2ViewController ()<UIWebViewDelegate, WKNavigationDelegate>

@property (weak, nonatomic) IBOutlet UISegmentedControl *webViewSegmentedCtrl;
@property (weak, nonatomic) IBOutlet UIButton *loadHTMLStringBtnLeft;
@property (weak, nonatomic) IBOutlet UIButton *loadDataBtnLeft;
@property (weak, nonatomic) IBOutlet UIButton *loadRequestBtnLeft;

@property (weak, nonatomic) IBOutlet UIButton *loadHTMLStringBtnRight;
@property (weak, nonatomic) IBOutlet UIButton *loadDataBtnRight;
@property (weak, nonatomic) IBOutlet UIButton *loadRequestBtnRight;

@property (strong, nonatomic) WebViewTestContext *webViewTestContextLeft;
@property (strong, nonatomic) WebViewTestContext *webViewTestContextRight;

@end

@implementation WebView2ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    // bind event
    [self bindEvent];
    
    // init
    self.webViewTestContextLeft = [[WebViewTestContext alloc] initWithWebView:[[UIWebViewTarget alloc] init]];
    self.webViewTestContextRight = [[WebViewTestContext alloc] initWithWebView:[[UIWebViewTarget alloc] init]];
    
    [self.view addSubview:(UIView *)self.webViewTestContextLeft.webView];
    [self.view addSubview:(UIView *)self.webViewTestContextRight.webView];
    
    [self.webViewTestContextLeft.webView setDelegate:self];
    [self.webViewTestContextRight.webView setDelegate:self];
    
    // layout
    [self setLayout];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)setLayout {
    UIView *leftView = [_webViewTestContextLeft.webView getView];
    UIView *rightView = [_webViewTestContextRight.webView getView];
    [leftView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(rightView);
        make.leading.equalTo(self.view.mas_leading);
        make.top.equalTo(self.webViewSegmentedCtrl.mas_bottom);
        make.bottom.equalTo(self.view.mas_bottom);
    }];
    
    [rightView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(leftView);
        make.leading.equalTo(leftView.mas_trailing);
        make.trailing.equalTo(self.view.mas_trailing);
        make.top.equalTo(leftView);
        make.bottom.equalTo(self.view.mas_bottom);
    }];
}

/**
 绑定事件
 */
- (void)bindEvent {
    [_loadHTMLStringBtnLeft addTarget:self action:@selector(loadHTMLString:) forControlEvents:UIControlEventTouchUpInside];
    [_loadHTMLStringBtnRight addTarget:self action:@selector(loadHTMLString:) forControlEvents:UIControlEventTouchUpInside];
    [_loadDataBtnLeft addTarget:self action:@selector(loadData:) forControlEvents:UIControlEventTouchUpInside];
    [_loadDataBtnRight addTarget:self action:@selector(loadData:) forControlEvents:UIControlEventTouchUpInside];
    [_loadRequestBtnLeft addTarget:self action:@selector(loadRequest:) forControlEvents:UIControlEventTouchUpInside];
    [_loadRequestBtnRight addTarget:self action:@selector(loadRequest:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)loadHTMLString:(id)sender {
    if (sender == _loadHTMLStringBtnLeft) {
        [_webViewTestContextLeft loadHtmlStringWithHtmlFileName:@"JSDemo"];
    } else {
        [_webViewTestContextRight loadHtmlStringWithHtmlFileName:@"index"];
    }
}

- (void)loadData:(id)sender {
    if (sender == _loadDataBtnLeft) {
        [_webViewTestContextLeft loadDataWithHtmlFileName:@"index"];
    } else {
        [_webViewTestContextRight loadDataWithHtmlFileName:@"index"];
    }
}

- (void)loadRequest:(id)sender {
    if (sender == _loadRequestBtnLeft) {
        [_webViewTestContextLeft loadRequestWithUrlString:@"http://dv.youku.com"];
    } else {
        [_webViewTestContextRight loadRequestWithUrlString:@"http://m.leyou.com.cn/mall"];
    }
}

#pragma mark -UIWebViewDelegate
-(void)webViewDidFinishLoad:(UIWebView *)webView{
    
    NSString *str = [webView stringByEvaluatingJavaScriptFromString:@"document.location.href"];
    NSLog(@"［webViewDidFinishLoad］：%@",str);
    
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    NSLog(@"%@",[[request URL] absoluteString]);
    return YES;
}

- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(null_unspecified WKNavigation *)navigation {
    NSLog(@"%@", [webView.URL absoluteString]);
}

- (IBAction)segmentedControlValueChanged:(UISegmentedControl *)sender {
    id<UIWebViewTargetInterface> newWebviewLeft = nil;
    id<UIWebViewTargetInterface> newWebviewRight = nil;
    switch (sender.selectedSegmentIndex) {
        case 0:
        {
            newWebviewLeft = [[self class] _getWebViewByType:WebViewTypeUIWebView];
            newWebviewRight = [[self class] _getWebViewByType:WebViewTypeUIWebView];
        }
            break;
        case 1:
        {
            newWebviewLeft = [[self class] _getWebViewByType:WebViewTypeWKWebView];
            newWebviewRight = [[self class] _getWebViewByType:WebViewTypeWKWebView];
        }
            break;
            
        default:
            NSAssert(1, @"segment expection");
    }
    [[_webViewTestContextLeft.webView getView] removeFromSuperview];
    _webViewTestContextLeft.webView = newWebviewLeft;
    [self.view addSubview:[_webViewTestContextLeft.webView getView]];
    
    [[_webViewTestContextRight.webView getView] removeFromSuperview];
    _webViewTestContextRight.webView = newWebviewRight;
    [self.view addSubview:[_webViewTestContextRight.webView getView]];
    [self setLayout];
}

@end
