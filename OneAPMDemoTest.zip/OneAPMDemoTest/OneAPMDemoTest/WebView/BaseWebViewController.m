//
//  BaseWebViewController.m
//  OneAPMDemoTest
//
//  Created by yuxr on 17/3/13.
//  Copyright © 2017年 Jun Li. All rights reserved.
//

#import "BaseWebViewController.h"
#import <WebKit/WebKit.h>
#import "UIWebViewTargetInterface.h"
#import "WKWebViewAdapter.h"

@interface BaseWebViewController ()

@end

@implementation BaseWebViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

+ (id)_getWebViewByType:(WebViewType)webViewType {
    id<UIWebViewTargetInterface> newWebview = nil;
    if (webViewType == WebViewTypeWKWebView) {
        WKWebView *webview = [[WKWebView alloc] init];
        newWebview = [[WKWebViewAdapter alloc] initWithWebView:webview];
    } else {
        newWebview = [[UIWebViewTarget alloc] init];
    }
    return newWebview;
}


@end
