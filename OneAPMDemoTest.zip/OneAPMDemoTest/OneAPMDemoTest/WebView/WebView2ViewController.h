//
//  WebView2ViewController.h
//  OneAPMDemoTest
//
//  Created by JunLee on 15/12/14.
//  Copyright © 2015年 Jun Li. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseWebViewController.h"

@interface WebView2ViewController : BaseWebViewController

@end
