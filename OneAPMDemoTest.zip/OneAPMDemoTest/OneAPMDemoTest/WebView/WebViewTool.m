//
//  WebViewTool.m
//  OneAPMDemoTest
//
//  Created by yuxr on 17/3/13.
//  Copyright © 2017年 Jun Li. All rights reserved.
//

#import "WebViewTool.h"

@implementation WebViewTool

+ (NSData *)getDataWithHtmlFileName:(NSString *)fileName {
    
    NSString *htmlPath = [[NSBundle mainBundle] pathForResource:fileName ofType:@"html"];
    NSData *htmlData = [[NSData alloc] initWithContentsOfFile:htmlPath];
    return htmlData;
}

+ (NSString *)getHTMLStringWithHtmlFileName:(NSString *)fileName {
    NSString *htmlPath = [[NSBundle mainBundle] pathForResource:fileName ofType:@"html"];
    NSString *html = [[NSString alloc] initWithContentsOfFile:htmlPath encoding:NSUTF8StringEncoding error:nil];
    return html;
}

@end
