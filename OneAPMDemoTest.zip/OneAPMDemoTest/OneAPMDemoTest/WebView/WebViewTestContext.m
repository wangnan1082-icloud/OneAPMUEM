//
//  WebViewTestContext.m
//  OneAPMDemoTest
//
//  Created by yuxr on 17/3/13.
//  Copyright © 2017年 Jun Li. All rights reserved.
//

#import "WebViewTestContext.h"
#import "WebViewTool.h"

@implementation WebViewTestContext

- (instancetype)initWithWebView:(id<UIWebViewTargetInterface>)webView {
    if (self = [super init]) {
        _webView = webView;
        [self commonInit];
    }
    return self;
}

- (void)commonInit {
    ((UIView *)_webView).backgroundColor = [UIColor clearColor];
    if ([_webView isUIWebView]) {
        ((UIWebView *)_webView).dataDetectorTypes = UIDataDetectorTypeLink;
    }
}

- (void)setWebView:(id<UIWebViewTargetInterface>)webView {
    _webView = webView;
    [self commonInit];
}

- (void)loadRequestWithUrlString:(NSString *)url {
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
    // 这里load两次
    [_webView loadRequest:request];
    [_webView loadRequest:request];
}

- (void)loadDataWithHtmlFileName:(NSString *)fileName {
    [_webView loadData:[WebViewTool getDataWithHtmlFileName:fileName]
                            MIMEType:@"text/html" textEncodingName:@"UTF-8"
                             baseURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] bundlePath]]];
}

- (void)loadHtmlStringWithHtmlFileName:(NSString *)fileName {
    [_webView loadHTMLString:[WebViewTool getHTMLStringWithHtmlFileName:fileName]
                     baseURL:[[NSBundle mainBundle] bundleURL]];
    [_webView loadHTMLString:[WebViewTool getHTMLStringWithHtmlFileName:fileName]
                     baseURL:[[NSBundle mainBundle] bundleURL]];
}

@end
