//
//  WKWebViewAdapter.h
//  OneAPMDemoTest
//
//  Created by yuxr on 17/3/13.
//  Copyright © 2017年 Jun Li. All rights reserved.
//

#import <WebKit/WebKit.h>
#import "UIWebViewTargetInterface.h"

@interface UIWebViewTarget : UIWebView <UIWebViewTargetInterface>

@end

@interface WKWebViewAdapter : NSObject <UIWebViewTargetInterface>

- (instancetype)initWithWebView:(WKWebView *)webView;

@end
