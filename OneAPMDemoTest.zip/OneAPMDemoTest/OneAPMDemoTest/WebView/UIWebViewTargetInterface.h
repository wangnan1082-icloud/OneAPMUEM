//
//  UIWebViewTargetInterface.h
//  OneAPMDemoTest
//
//  Created by yuxr on 17/3/13.
//  Copyright © 2017年 Jun Li. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol UIWebViewTargetInterface <NSObject>

- (BOOL)isUIWebView;
- (UIView * _Nonnull)getView;
- (void)setDelegate:(id _Nonnull)delegate;
- (void)loadRequest:(NSURLRequest * _Nonnull)request;
- (void)loadHTMLString:(NSString * _Nonnull)string baseURL:(NSURL * _Nonnull)baseURL;
- (void)loadData:(NSData * _Nonnull)data MIMEType:(NSString * _Nonnull)MIMEType textEncodingName:(NSString * _Nonnull)textEncodingName baseURL:(NSURL * _Nullable)baseURL;

@end
