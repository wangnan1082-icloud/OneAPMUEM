//
//  WebViewTool.h
//  OneAPMDemoTest
//
//  Created by yuxr on 17/3/13.
//  Copyright © 2017年 Jun Li. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WebViewTool : NSObject

+ (NSData *)getDataWithHtmlFileName:(NSString *)fileName;
+ (NSString *)getHTMLStringWithHtmlFileName:(NSString *)fileName;

@end
