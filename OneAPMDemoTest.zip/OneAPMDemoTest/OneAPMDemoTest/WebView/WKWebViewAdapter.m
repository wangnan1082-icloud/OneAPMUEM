//
//  WKWebViewAdapter.m
//  OneAPMDemoTest
//
//  Created by yuxr on 17/3/13.
//  Copyright © 2017年 Jun Li. All rights reserved.
//

#import "WKWebViewAdapter.h"

@implementation UIWebViewTarget

- (BOOL)isUIWebView {
    return YES;
}

- (UIView * _Nonnull)getView {
    return self;
}

@end

@interface WKWebViewAdapter ()

@property (nonatomic, strong) WKWebView *webView;

@end

@implementation WKWebViewAdapter

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (instancetype)initWithWebView:(WKWebView *)webView {
    if (self = [super init]) {
        _webView = webView;
        _webView.configuration.preferences.minimumFontSize = 50;
    }
    
    return self;
}

- (BOOL)isUIWebView {
    return NO;
}

- (UIView *)getView {
    return _webView;
}

- (void)setDelegate:(id _Nonnull)delegate {
    _webView.navigationDelegate = delegate;
}

- (void)loadRequest:(NSURLRequest * _Nonnull)request {
    _webView.configuration.preferences.minimumFontSize = 10;
    [_webView loadRequest:request];
}

- (void)loadHTMLString:(NSString *)string baseURL:(NSURL *)baseURL {
    _webView.configuration.preferences.minimumFontSize = 50;
    [_webView loadHTMLString:string baseURL:baseURL];
}

- (void)loadData:(NSData *)data MIMEType:(NSString *)MIMEType textEncodingName:(NSString *)textEncodingName baseURL:(NSURL *)baseURL {
    _webView.configuration.preferences.minimumFontSize = 50;
    [_webView loadData:data MIMEType:MIMEType characterEncodingName:textEncodingName baseURL:baseURL];
}


//- (void)loadHTMLString:(NSString * _Nonnull)string baseURL:(NSURL * _Nonnull)baseURL;
//- (void)loadData:(NSData * _Nonnull)data MIMEType:(NSString * _Nonnull)MIMEType textEncodingName:(NSString * _Nonnull)textEncodingName baseURL:(NSURL * _Nullable)baseURL;

- (id)forwardingTargetForSelector:(SEL)aSelector {
    return _webView;
}

@end
