//
//  WebViewTestContext.h
//  OneAPMDemoTest
//
//  Created by yuxr on 17/3/13.
//  Copyright © 2017年 Jun Li. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "UIWebViewTargetInterface.h"

@interface WebViewTestContext : NSObject

@property (nonatomic, strong) id<UIWebViewTargetInterface> webView;

//- (instancetype)initWithStrategy:(id<WebViewTestStrategyProtocol>)strategy;

- (instancetype)initWithWebView:(id<UIWebViewTargetInterface>)webView;

- (void)loadRequestWithUrlString:(NSString *)url;

- (void)loadDataWithHtmlFileName:(NSString *)fileName;

- (void)loadHtmlStringWithHtmlFileName:(NSString *)fileName;

@end
