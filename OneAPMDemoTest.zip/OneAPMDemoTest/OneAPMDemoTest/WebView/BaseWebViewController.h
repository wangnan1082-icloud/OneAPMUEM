//
//  BaseWebViewController.h
//  OneAPMDemoTest
//
//  Created by yuxr on 17/3/13.
//  Copyright © 2017年 Jun Li. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, WebViewType) {
    WebViewTypeUIWebView,
    WebViewTypeWKWebView
};

@interface BaseWebViewController : UIViewController

+ (id)_getWebViewByType:(WebViewType)webViewType;

@end
