//
//  WebViewTestViewController.m
//  OneAPMDemo
//
//  Created by JunLee on 15/12/2.
//  Copyright © 2015年 李家龙. All rights reserved.
//

#import "WebViewTestViewController.h"
#import <WebKit/WebKit.h>

@interface WebViewTestViewController ()<UIWebViewDelegate, WKNavigationDelegate>

@property (weak, nonatomic) IBOutlet UISegmentedControl *segmentedControl;
@property (strong, nonatomic) WebViewTestContext *webViewTestContext;

@end

@implementation WebViewTestViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // init
    self.webViewTestContext = [[WebViewTestContext alloc] initWithWebView:[[UIWebViewTarget alloc] init]];
    [self.view addSubview:[self.webViewTestContext.webView getView]];
    [self.webViewTestContext.webView setDelegate:self];
    [self setLayout];
    
    for (UIView * aView in [self.webViewTestContext.webView getView].subviews )
    {
        if ([aView isKindOfClass:[UIScrollView class]])
        {
            [(UIScrollView *)aView setShowsVerticalScrollIndicator:NO];
            [(UIScrollView *)aView setShowsHorizontalScrollIndicator:NO];
        }
        
        for (UIView *inScrollView in aView.subviews)
        {
            if ([inScrollView isKindOfClass:[UIImageView class]])
            {
                inScrollView.hidden =YES;
            }
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)setLayout {
    UIView *webview = [_webViewTestContext.webView getView];
    [webview mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.and.right.equalTo(self.view);
        make.top.equalTo(self.segmentedControl.mas_bottom);
        make.bottom.equalTo(self.view);
    }];
}

- (IBAction)testHTMLString:(id)sender {
    [_webViewTestContext loadHtmlStringWithHtmlFileName:@"index"];
}

- (IBAction)testLoadData:(id)sender {
    [_webViewTestContext loadDataWithHtmlFileName:@"JSDemo"];
}

- (IBAction)testLoadRequest:(id)sender {
    NSString *htmlPath = [[NSBundle mainBundle] pathForResource:@"index" ofType:@"html"];
    
    [_webViewTestContext loadRequestWithUrlString:[NSURL fileURLWithPath:htmlPath isDirectory:NO].absoluteString];
}

+ (NSString *)throwErrorScript {
    return @"err = new Error('error');err.type ='abcde';console.info(err);throw err;";
}

#pragma mark -UIWebViewDelegate 
-(void)webViewDidFinishLoad:(UIWebView *)webView{
    [webView stringByEvaluatingJavaScriptFromString:[[self class] throwErrorScript]];
    NSString *str = [webView stringByEvaluatingJavaScriptFromString:@"document.location.href"];
    NSLog(@"［webViewDidFinishLoad］：%@",str);
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    NSLog(@"absoluteString URL:%@",[[request URL] absoluteString]);
    return YES;
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation {
    WKUserScript *script = [[WKUserScript alloc] initWithSource:[[self class] throwErrorScript] injectionTime:WKUserScriptInjectionTimeAtDocumentEnd forMainFrameOnly:YES];
    
    [webView.configuration.userContentController addUserScript:script];
}

- (IBAction)segmentControlValueChanged:(UISegmentedControl *)sender {
    id<UIWebViewTargetInterface> newWebview = nil;
    switch (sender.selectedSegmentIndex) {
        case 0:
        {
            newWebview = [[self class] _getWebViewByType:WebViewTypeUIWebView];
        }
            break;
        case 1:
        {
            newWebview = [[self class] _getWebViewByType:WebViewTypeWKWebView];
        }
            break;
            
        default:
            NSAssert(1, @"segment expection");
    }
    [[_webViewTestContext.webView getView] removeFromSuperview];
    _webViewTestContext.webView = newWebview;
    [self.view addSubview:[_webViewTestContext.webView getView]];
    [self setLayout];
}

@end
