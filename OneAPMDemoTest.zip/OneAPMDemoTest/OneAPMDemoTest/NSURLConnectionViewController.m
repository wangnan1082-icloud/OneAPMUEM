//
//  NSURLConnectionViewController.m
//  OneAPMDemo
//
//  Created by 李家龙 on 15/10/26.
//  Copyright © 2015年 李家龙. All rights reserved.
//

#define  KConnectionPostURL   @"http://10.128.17.189/flights/queryflights.html"
#define  KConnectionGetURL @"www.baidu.com"// @"http://10.128.17.189/flights.html" // 

// @"http://api.hudong.com/iphonexml.do"]; NSURL POST

//@"https://api.app.net/"; //AFNetWorking

// @"http://f12.topit.me/o129/10129120625790e866.jpg" // URLSession

// URLSession
#define  KSessionUploadURL   @"www.baidu.com"
#define  KSessionDownloadURL   @"www.baidu.com"
#define  KSessionTaskURL   @"www.baidu.com"
#define  KSessionPostURL   @"www.baidu.com"

#import "NSURLConnectionViewController.h"

@interface NSURLConnectionViewController ()
{
    NSURLRequest *_postRequest;
    
    NSURLRequest *_getRequest;
}
@end

@implementation NSURLConnectionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    if (_postURLTF.text) {
         _postRequest = [[NSURLRequest alloc]initWithURL:[NSURL URLWithString:_postURLTF.text]];
    }else{
        _postRequest = [[NSURLRequest alloc]initWithURL:[NSURL URLWithString:KConnectionPostURL]];
    }
    
    if (_GetURLTF.text) {
        _getRequest = [[NSURLRequest alloc]initWithURL:[NSURL URLWithString: KConnectionGetURL]]; //_GetURLTF.text]];
    }else{
        _getRequest = [[NSURLRequest alloc]initWithURL:[NSURL URLWithString:KConnectionGetURL]];
    }

}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (IBAction)postAction:(id)sender {
//    NSURLConnection *connection = [[NSURLConnection alloc]initWithRequest:_postRequest delegate:self];
//    [connection start];
    
    //第一步，创建URL
    
    NSURL *url = [NSURL URLWithString:@"http://api.hudong.com/iphonexml.do"];
    
    //第二步，创建请求
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc]initWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:10];
    
    [request setHTTPMethod:@"POST"];//设置请求方式为POST，默认为GET
    
    NSString *str = @"type=focus-c";//设置参数
    NSData *data = [str dataUsingEncoding:NSUTF8StringEncoding];
    [request setHTTPBody:data];
    
    //第三步，连接服务器
    NSData *received = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    NSString *str1 = [[NSString alloc]initWithData:received encoding:NSUTF8StringEncoding];
    NSLog(@"received ：%@",str1);
}

- (IBAction)getAction:(id)sender {
    
      _getRequest = [[NSURLRequest alloc]initWithURL:[NSURL URLWithString: KConnectionGetURL]]; //
    NSURLConnection *connection = [[NSURLConnection alloc]initWithRequest:_getRequest delegate:self];
    [connection start];
}
- (IBAction)getByBlockAction:(id)sender {
    
    NSLog(@"通过block回调");
    
    NSOperationQueue *queue = [NSOperationQueue mainQueue];
    __block    NSURLRequest *request = _getRequest;

   //发送异步步请求

    [NSURLConnection sendAsynchronousRequest:request
                                       queue:queue
                           completionHandler:^(NSURLResponse *response, NSData *  data, NSError * connectionError) {
                                              
                                              NSLog(@"--block回调数据--%@---%lu", [NSThread currentThread],data.length);
                                          }];
    
//    // ios9 新的
//     NSURLSession *session = [NSURLSession sharedSession];
//    [session  dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error){ NSLog(@"NSURLSession 回调数据-%@-%lu", [NSThread currentThread],data.length ); }]; //dataTaskWithRequest:completionHandler:]
}
- (IBAction)postByBlockAction:(id)sender {
    
    //第一步，创建URL
    
    NSURL *url = [NSURL URLWithString:@"http://api.hudong.com/iphonexml.do"];
    
    //第二步，创建请求
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc]initWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:10];
    
    [request setHTTPMethod:@"POST"];//设置请求方式为POST，默认为GET
    
    NSString *str = @"type=focus-c";//设置参数
    NSData *data = [str dataUsingEncoding:NSUTF8StringEncoding];
    [request setHTTPBody:data];

    
    NSOperationQueue *queue=[NSOperationQueue mainQueue];
    //异步
    [NSURLConnection sendAsynchronousRequest:request queue:queue completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
               NSLog(@"--block回调数据--%@---%lu", [NSThread currentThread],(unsigned long)data.length);
      
        NSString *str __unused = [NSString stringWithFormat:@"%@",data];
        NSLog(@"data :%@",response);

;
        
            }];
    NSLog(@"请求发送完毕");
}

#pragma mark -NSURLConnectionDelegate,NSURLConnectionDataDelegate
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    NSLog(@"请求成功，didReceiveResponse: %@",response);
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    NSLog(@"请求成功，didReceiveData:%@",data);
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSLog(@"请求完成，connection:%@",connection);
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(nonnull NSError *)error
{
    NSLog(@"请求出错%@",error);
}
- (IBAction)downFile:(id)sender {
    
    NSURL *url1=[NSURL URLWithString:@"http://www.baidu.com/img/bdlogo.png"]; //图片
    //@"http://dldir1.qq.com/qqfile/QQforMac/QQ_V3.1.2.dmg"
              
    NSMutableURLRequest* request1=[NSMutableURLRequest requestWithURL:url1];
    [request1 setValue:@"bytes=0-499" forHTTPHeaderField:@"Range"];
    
    [request1 setCachePolicy:NSURLRequestReloadIgnoringLocalCacheData];
    
//    NSData *returnData1 = [NSURLConnection sendSynchronousRequest:request1
//                                                returningResponse:nil
//                                                            error:nil];
    
    
    NSOperationQueue *queue = [NSOperationQueue mainQueue];
    __block    NSURLRequest *request __unused = _getRequest;
    
    //发送异步步请求
    
      [NSURLConnection sendAsynchronousRequest:request1
                                       queue:queue
                           completionHandler:^(NSURLResponse *response, NSData *  data, NSError * connectionError) {
                               
                               NSLog(@"--block回调数据--%@---%lu", [NSThread currentThread],data.length);
                               
                               [self writeToFile:data fileName:@"SOMEPATH"];
                           }];
    
    
    
}

-(void)writeToFile:(NSData *)data fileName:(NSString *) fileName
{
        NSString *filePath=[NSString stringWithFormat:@"%@",fileName];
        if([[NSFileManager defaultManager] fileExistsAtPath:filePath] == NO){
            
            NSLog(@"file not exist,create it...");
            [[NSFileManager defaultManager] createFileAtPath:filePath
                                                    contents:nil
                                                  attributes:nil];
        }else {
            NSLog(@"file exist!!!");
        }
        
        FILE *file = fopen([fileName UTF8String], [@"ab+" UTF8String]);
        
        if(file != NULL){
            fseek(file, 0, SEEK_END);
        }
        int readSize = (int)[data length];
        fwrite((const void *)[data bytes], readSize, 1, file);
        fclose(file);  
    }
@end
