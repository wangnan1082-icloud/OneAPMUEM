//
//  AACheckinViewController.m
//  OneAPMDemoTest
//
//  Created by JunLee on 16/3/11.
//  Copyright © 2016年 Jun Li. All rights reserved.
//

#import "AACheckinViewController.h"
#import "MJExtension.h"
#import "FlightModel.h"
#import "BookingModel.h"
@interface AACheckinViewController ()<NSURLConnectionDelegate,UITableViewDataSource,UITableViewDelegate>
@property (nonatomic,strong)NSURLConnection *connection;
@property (nonatomic,strong)NSMutableData *myResponseData;
@property (weak, nonatomic) IBOutlet UITableView *bookingList;
@property (nonatomic,strong)NSMutableArray *bookinglistArray;
@end

@implementation AACheckinViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.bookingList.delegate = self;
    self.bookingList.dataSource = self;
    [self postbrowseflights];
    
}
-(void)postbrowseflights{
    NSString *urlString =[NSString stringWithFormat:@"http://123.56.97.180/rest/api/bookings/byuser/uid0@email.com" ]; //,@"uid0@email.com"];
    NSString *encodeURLString = [urlString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL *url = [NSURL URLWithString:encodeURLString];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url];
    self.connection = [[NSURLConnection alloc]initWithRequest:request delegate:self];
    
    [self.connection start];
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    NSLog(@"response : %@",response);
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
//     NSLog(@"response data : %@",data);
//    NSLog(@"%@", [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding]);
    [self.myResponseData appendData:data];
}
- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    
    NSString *responseStr = [[NSString alloc] initWithData:self.myResponseData encoding:NSUTF8StringEncoding];
    
    NSData *jsonData = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
    NSError *err;
    NSArray * jsonArray = [NSJSONSerialization JSONObjectWithData:jsonData
                                                        options:NSJSONReadingMutableContainers
                                                          error:&err];
    
     NSLog(@" 接收结束jsonArray==%@ ",jsonArray);
    BookingModel *Model __unused = [[BookingModel alloc] init];

    self.bookinglistArray = [BookingModel mj_objectArrayWithKeyValuesArray:jsonArray];
    [self.bookingList reloadData];
//    Model = array[1];
//        NSLog(@"%@", Model.dateOfBooking);
}

- (void )connection:(NSURLConnection *)connection didFailWithError:(NSError *)error  {
    //[self performSelectorOnMainThread:@selector(httpConnectEnd) withObject:nil  waitUntilDone:NO];
    NSLog(@"接收到错误%@",[error localizedDescription]);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
  
    // Dispose of any resources that can be recreated.
}

-(NSMutableData*)myResponseData{
    
    if (_myResponseData == nil) {
        _myResponseData = [[NSMutableData alloc] init];
    }
    return _myResponseData;
}
-(NSMutableArray *)bookinglistArray{
    if (_bookinglistArray == nil) {
        _bookinglistArray = [[NSMutableArray alloc] init];
    }
    return _bookinglistArray;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark - UITableViewDataSource,UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.bookinglistArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString* cellIdentifier = @"Cell";
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier]; //[[[NSBundle mainBundle]loadNibNamed:@"goodsListCell" owner:self options:nil] lastObject];
    }
    BookingModel *model = self.bookinglistArray[indexPath.row];
//    [cell setGoodsListCell:goodsD];
    cell.textLabel.text = model.dateOfBooking;
    return cell;
}
@end
