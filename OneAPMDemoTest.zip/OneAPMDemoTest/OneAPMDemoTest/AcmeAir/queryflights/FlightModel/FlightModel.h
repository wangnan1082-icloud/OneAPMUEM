//
//  FlightModel.h
//  OneAPMDemoTest
//
//  Created by JunLee on 16/3/14.
//  Copyright © 2016年 Jun Li. All rights reserved.
//

/*
 "flight": {
 "pkey": {
 "id": "2c5d5da8-b937-4720-9226-0f0fca14e14b",
 "flightSegmentId": "AA467"
 },
 "scheduledDepartureTime": 1454457600000,
 "scheduledArrivalTime": 1454464800000,
 "firstClassBaseCost": 500,
 "economyClassBaseCost": 200,
 "numFirstClassSeats": 10,
 "numEconomyClassSeats": 200,
 "airplaneTypeId": "B747",
 "flightSegment": null,
 "flightSegmentId": "AA467"
 }
 
 */

#import <Foundation/Foundation.h>

@interface FlightModel : NSObject
@property (nonatomic,strong)NSDictionary *pkey;
@property (nonatomic,strong)NSString *scheduledDepartureTime;
@property (nonatomic,strong)NSString *scheduledArrivalTime;
@property (nonatomic,strong)NSString *firstClassBaseCost;
@property (nonatomic,strong)NSString *economyClassBaseCost;
@property (nonatomic,strong)NSString *numFirstClassSeats;
@property (nonatomic,strong)NSString *numEconomyClassSeats;
@property (nonatomic,strong)NSString *airplaneTypeId;
@property (nonatomic,strong)NSString *flightSegment;
@property (nonatomic,strong)NSString *flightSegmentId;
@end
