//
//  BookingModel.h
//  OneAPMDemoTest
//
//  Created by JunLee on 16/3/14.
//  Copyright © 2016年 Jun Li. All rights reserved.
//

/*
 {
 customer =         {
 address =             {
 city = Anytown;
 country = USA;
 postalCode = 27717;
 stateProvince = NC;
 streetAddress1 = "223 Main St.";
 streetAddress2 = "<null>";
 };
 "miles_ytd" = 1000;
 password = password;
 phoneNumber = "919-123-4567";
 phoneNumberType = BUSINESS;
 status = GOLD;
 "total_miles" = 1000000;
 username = "uid0@email.com";
 };
 dateOfBooking = 1457944255000;
 flight =         {
 airplaneTypeId = B747;
 economyClassBaseCost = 200;
 firstClassBaseCost = 500;
 flightSegment = "<null>";
 flightSegmentId = AA467;
 numEconomyClassSeats = 200;
 numFirstClassSeats = 10;
 pkey =             {
 flightSegmentId = AA467;
 id = "2c5d5da8-b937-4720-9226-0f0fca14e14b";
 };
 scheduledArrivalTime = 1454464800000;
 scheduledDepartureTime = 1454457600000;
 };
 flightId = "2c5d5da8-b937-4720-9226-0f0fca14e14b";
 flightSegmentId = AA467;
 pkey =         {
 customerId = "uid0@email.com";
 id = "65043fe2-0dc7-4134-912c-5e4104a7b738";
 };
 */

#import <Foundation/Foundation.h>

@interface BookingModel : NSObject
@property (nonatomic,strong)NSDictionary *customer;
@property (nonatomic,copy)NSString *dateOfBooking;
@property (nonatomic,strong)NSDictionary *flight;
@property (nonatomic,copy)NSString *flightId;
@property (nonatomic,copy)NSString *flightSegmentId;
@property (nonatomic,strong)NSDictionary *pkey;
@end
