//
//  AALoginViewController.m
//  OneAPMDemoTest
//
//  Created by JunLee on 16/3/11.
//  Copyright © 2016年 Jun Li. All rights reserved.
//

#import "AALoginViewController.h"
#import "AACheckinViewController.h"

@interface AALoginViewController ()
@property (weak, nonatomic) IBOutlet UITextField *idTF;
@property (weak, nonatomic) IBOutlet UITextField *passwordTF;

@end

@implementation AALoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.idTF.text = @"uid0@email.com";
    self.passwordTF.text = @"password";
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)LoginBtnTap:(id)sender {
    
    NSURL *url = [NSURL URLWithString:@"http://123.56.97.180/rest/api/login"];
    
    NSString *post=[NSString stringWithFormat:@"login=%@&password=%@",self.idTF.text,self.passwordTF.text ] ;
    NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    [request setHTTPMethod:@"POST"];
   [request setHTTPBody:postData];
    [request setTimeoutInterval:10.0];
    
    NSOperationQueue *queue = [[NSOperationQueue alloc]init];
    [NSURLConnection sendAsynchronousRequest:request
                                       queue:queue
                           completionHandler:^(NSURLResponse *response, NSData *data, NSError *error){
                               if (error) {
                                   NSLog(@"Httperror:%@%ld", error.localizedDescription,(long)error.code);
                               }else{
                                   
                                   NSInteger responseCode = [(NSHTTPURLResponse *)response statusCode];
                                   
                                   NSString *responseString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                                   
                                   NSLog(@"HttpResponseCode:%ld", (long)responseCode);
                                   NSLog(@"HttpResponseBody %@",responseString);
                                   if(responseCode == 200){
                                       NSLog(@"跳转");
                                       dispatch_async(dispatch_get_main_queue(), ^{
                                           
                                           AACheckinViewController * checkVC = [[AACheckinViewController alloc] init];
                                           [self.navigationController pushViewController:checkVC animated:YES];
                                       });
                                   }
                               }
                           }];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
