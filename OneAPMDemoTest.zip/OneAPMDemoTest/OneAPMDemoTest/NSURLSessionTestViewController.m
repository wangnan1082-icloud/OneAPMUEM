//
//  NSURLSessionTestViewController.m
//  OneAPMDemoTest
//
//  Created by JunLee on 16/3/15.
//  Copyright © 2016年 Jun Li. All rights reserved.
//

#import "NSURLSessionTestViewController.h"

@interface NSURLSessionTestViewController ()
@property (weak, nonatomic) IBOutlet UIWebView *webView;

@end

@implementation NSURLSessionTestViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)NSURLSessionBtn:(id)sender {
    
    // 创建Data Task，用于打开我的csdn blog主页
    NSURL *url = [NSURL URLWithString:@"http://blog.csdn.net/u010962810"];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error) {
        // 输出返回的状态码，请求成功的话为200
        [self showResponseCode:response];
        
        NSLog(@"nssetion完成，当前在%@线程",[NSThread currentThread]);
        // 在webView中加载数据
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.webView loadData:data MIMEType:@"text/html" textEncodingName:@"utf-8" baseURL:url];
        });
    }];
    // 使用resume方法启动任务
    [dataTask resume];
}

/* 输出http响应的状态码 */
- (void)showResponseCode:(NSURLResponse *)response {
    NSHTTPURLResponse* httpResponse = (NSHTTPURLResponse*)response;
    NSInteger responseStatusCode = [httpResponse statusCode];
    NSLog(@"responseStatusCode%ld", (long)responseStatusCode);
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
