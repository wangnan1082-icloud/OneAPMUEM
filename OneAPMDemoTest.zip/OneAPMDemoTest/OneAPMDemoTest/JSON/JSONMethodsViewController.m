//
//  JSONMethodsViewController.m
//  OneAPMDemo
//
//  Created by JunLee on 15/11/26.
//  Copyright © 2015年 李家龙. All rights reserved.
//

#import "JSONMethodsViewController.h"

@interface JSONMethodsViewController ()
@property (weak, nonatomic) IBOutlet UITextView *jsonText;


@end

@implementation JSONMethodsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];

    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)JsonSerializationParse:(id)sender {
    
    NSLog(@"JSOn");
    
    //加载一个NSURL对象
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://mobile.weather.com.cn/data/forecast/101010100.html?_=1381891660081"]];
    //将请求的url数据放到NSData对象中
    //    NSData *response = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    
    
    __weak JSONMethodsViewController *weakSelf = self;
    NSOperationQueue *queue = [[NSOperationQueue alloc]init];
    [NSURLConnection sendAsynchronousRequest:request
                                       queue:queue
                           completionHandler:^(NSURLResponse *response, NSData *data, NSError *error){
                               if (error) {
                                   NSLog(@"Httperror:%@%ld", error.localizedDescription,(long)error.code);
                               }else{
                                   //IOS5自带解析类NSJSONSerialization从response中解析出数据放到字典中
                                   NSDictionary *weatherDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
                                   
                                   dispatch_async(dispatch_get_main_queue(), ^{
                                       [weakSelf showWeather:weatherDic];
                                   });
                               }
                           }];

}

-(void) showWeather:(NSDictionary *)weatherDic{
    NSDictionary *weatherInfo = [weatherDic objectForKey:@"c"];
    
    self.jsonText.text = [NSString stringWithFormat:@"今天是 C: %@ , F: %@ ",[weatherInfo objectForKey:@"c2"],[weatherInfo objectForKey:@"c3"]];
    NSLog(@"weatherInfo字典里面的内容为--》%@", weatherDic );
}


@end
