//
//  Province.m
//  test
//
//  Created by katty on 13-6-20.
//  Copyright (c) 2013年 katty. All rights reserved.
//

#import "Province.h"


@implementation Province

@dynamic provinceid;
@dynamic provincename;
@dynamic cityid;
@dynamic cityname;

@end
