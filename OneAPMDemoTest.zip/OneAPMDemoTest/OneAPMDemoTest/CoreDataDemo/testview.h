//
//  testview.h
//  test
//
//  Created by katty on 13-6-20.
//  Copyright (c) 2013年 katty. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface testview : UIViewController
{
    IBOutlet UITextField *citytext;
    IBOutlet UITextField *provincetext;
    AppDelegate *mydelegate;
    
}

@property(nonatomic,strong)UITextField *citytext;
@property(nonatomic,strong)UITextField *provincetext;
@property(nonatomic,strong)AppDelegate *mydelegate;

-(IBAction)save:(UIButton *)sender;
-(IBAction)read:(UIButton *)sender;
-(IBAction)resignfirst:(id)sender;

@end
