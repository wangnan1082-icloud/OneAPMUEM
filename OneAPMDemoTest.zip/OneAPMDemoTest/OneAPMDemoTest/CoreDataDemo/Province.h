//
//  Province.h
//  test
//
//  Created by katty on 13-6-20.
//  Copyright (c) 2013年 katty. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface Province : NSManagedObject

@property (nonatomic, retain) NSNumber * provinceid;
@property (nonatomic, retain) NSString * provincename;
@property (nonatomic, retain) NSNumber * cityid;
@property (nonatomic, retain) NSString * cityname;

@end
