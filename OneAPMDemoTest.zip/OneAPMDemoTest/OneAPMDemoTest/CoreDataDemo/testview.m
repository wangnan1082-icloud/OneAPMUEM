//
//  testview.m
//  test
//
//  Created by katty on 13-6-20.
//  Copyright (c) 2013年 katty. All rights reserved.
//

#import "testview.h"
#import "AppDelegate.h"

#import <CoreData/CoreData.h>

@interface testview ()

@end

@implementation testview

@synthesize mydelegate,citytext,provincetext;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.mydelegate=(AppDelegate *)[[UIApplication sharedApplication]delegate];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(IBAction)save:(UIButton *)sender
{
    NSManagedObject *object=[NSEntityDescription insertNewObjectForEntityForName:@"Province" inManagedObjectContext:self.mydelegate.managedObjectContext];
      
    [object setValue:citytext.text forKey:@"cityname"];
    [object setValue:provincetext.text forKey:@"provincename"];
    
    [self.mydelegate saveContext];
    
    
}
-(IBAction)read:(id)sender
{
    NSFetchRequest *fetch=[[NSFetchRequest alloc]init];
    NSEntityDescription *object=[NSEntityDescription entityForName:@"Province" inManagedObjectContext:self.mydelegate.managedObjectContext];
    [fetch setEntity: object ];
    
    NSSortDescriptor *sort=[[NSSortDescriptor alloc]initWithKey:@"provincename" ascending:NO];
    NSLog(@"%@",sort);
    
    NSArray *sortarr=[[NSArray alloc]initWithObjects:sort, nil];
    [fetch setSortDescriptors:sortarr];
    
    NSError *error;
    NSArray *fetchresult=[self.mydelegate.managedObjectContext executeFetchRequest:fetch error:&error];
    
      for (NSManagedObject *object in fetchresult) {
        citytext.text=[object valueForKey:@"cityname"];
        provincetext.text=[object valueForKey:@"provincename"];
          NSLog(@"city:%@,province:%@ \n",[object valueForKey:@"cityname"],[object valueForKey:@"provincename"]);
          NSLog(@"%@",object);
    }
    // NSPredicate *pre=[NSPredicate predicateWithFormat:@"%@="];

   // NSLog(@"%@",fetchresult);


NSLog(@"fetchresult is :%@",fetchresult);


}
-(IBAction)resignfirst:(id)sender
{
    [sender resignFirstResponder];
}
@end
