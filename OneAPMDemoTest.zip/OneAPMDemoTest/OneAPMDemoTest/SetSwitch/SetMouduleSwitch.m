//
//  GetMouduleSwitch.m
//  OneAPMDemoTest
//
//  Created by 乔立征 on 16/8/11.
//  Copyright © 2016年 Jun Li. All rights reserved.
//

#import "SetMouduleSwitch.h"
#import <objc/message.h>

@implementation SetMouduleSwitch

+ (BOOL)getAppSwitch:(BOOL *)sdk
            activity:(BOOL *)activity
                http:(BOOL *)http
                ajax:(BOOL *)ajax
             webView:(BOOL *)webView
               crash:(BOOL *)crash
           httpError:(BOOL *)httpError
          httpHeader:(BOOL *)httpHeader {
    
    Class configCls = NSClassFromString(@"BLAgentSwitchConfig");
    
    if (!configCls) {
        return NO;
    }
    
    // get the sdk switch value
    *sdk = ((BOOL (*)(id, SEL))objc_msgSend)(configCls, NSSelectorFromString(@"isSdkEnabled"));
    
    // get the crash switch value
    *crash = ((BOOL (*)(id, SEL))objc_msgSend)(configCls, NSSelectorFromString(@"isCrashEnabled"));
    
    // get the HTTP switch value
    *http = ((BOOL (*)(id, SEL))objc_msgSend)(configCls, NSSelectorFromString(@"isHttpEnabled"));
    
    // get the HTTP switch value
    *httpError = ((BOOL (*)(id, SEL))objc_msgSend)(configCls, NSSelectorFromString(@"isHttpErrorEnabled"));
    
    // get the HttpHeader switch value
    *httpHeader = ((BOOL (*)(id, SEL))objc_msgSend)(configCls, NSSelectorFromString(@"isHttpHeaderEnabled"));
    
    // get the WebView switch value
    *webView = ((BOOL (*)(id, SEL))objc_msgSend)(configCls, NSSelectorFromString(@"isWebViewEnabled"));
    
    // get the HTTP switch value
    *ajax = ((BOOL (*)(id, SEL))objc_msgSend)(configCls, NSSelectorFromString(@"isAjaxEnabled"));
    
    // get the HTTP switch value
    *activity = ((BOOL (*)(id, SEL))objc_msgSend)(configCls, NSSelectorFromString(@"isActivityEnabled"));
    
    return YES;
}

@end
