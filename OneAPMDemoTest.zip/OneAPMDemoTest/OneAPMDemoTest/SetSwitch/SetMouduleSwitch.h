//
//  GetMouduleSwitch.h
//  OneAPMDemoTest
//
//  Created by 乔立征 on 16/8/11.
//  Copyright © 2016年 Jun Li. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SetMouduleSwitch : NSObject
/*
 **** app version - versionId ****
 *      5.0.1          24164
 *      2.2.4          
 ***** module    -  含义******
 *  switch.activity 交互详情
 *  switch.http 网络请求详情
 *  switch.ajax Ajax 请求
 *  switch.webview WebView 页面
 *  switch.crash 崩溃详情
 *  switch.http.error 是否采集网络错误详情数据 (只能设置 App 级别)
 *  switch.http.header 是否采集 HTTP Request/Response Header 数据(只能设置 App 级别)
 */

/*
 * @param changeString 格式：appId:versionId:module:switch，多个开关更新间用英文 '|' 分割，
 * 如果开关为 App 级别的，则 appVersion 设置为 0
 * @note 如果想打开某个版本 app 的某个模块，必须同时打开 app 级别的该模块开关和该版本 app 的该模块的开关
 */
+ (BOOL)getAppSwitch:(BOOL *)version
            activity:(BOOL *)activity
                http:(BOOL *)http
                ajax:(BOOL *)ajax
             webView:(BOOL *)webView
               crash:(BOOL *)crash
           httpError:(BOOL *)httpError
          httpHeader:(BOOL *)httpHeader;

@end
