//
//  ExtMainViewController.m
//  OneAPMDemoTest
//
//  Created by JieLiang Ma on 9/1/16.
//  Copyright © 2016 Jun Li. All rights reserved.
//

#import "ExtMainViewController.h"
#import "ExtSlowlyViewController.h"
#import "ExtSmoothlyViewController.h"
#import "ExtRemovePairInActionViewController.h"
#import "ExtBugfixMainViewController.h"
#import "ExtASIHttpRequestViewController.h"
#import "ExtNSURLConnectionViewController.h"
#import "ExtNSURLSessionViewController.h"
#import "ExtWebViewViewController.h"

@interface ExtMainSection : NSObject
@property (nonatomic, strong) NSString *sectionTitle;
@property (nonatomic, strong) NSArray<NSString *> *items;
@end
@implementation ExtMainSection
@end

@interface ExtMainViewController () <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray<ExtMainSection *> *dataSource;

@end

@implementation ExtMainViewController

- (instancetype)init {
    if (self = [super init]) {
        _dataSource = [[NSMutableArray alloc] init];
        _tableView  = [[UITableView alloc] init];
        _tableView.tableFooterView = [[UIView alloc] init];
        
        ExtMainSection *sectionActivity;

        sectionActivity = [ExtMainSection new];
        sectionActivity.sectionTitle = @"Socket";
        sectionActivity.items = @[@"ASIHttpRequest",
                                  @"NSURLConnection",
                                  @"NSURLSession",
                                  @"WebView"];

        [_dataSource addObject:sectionActivity];

        sectionActivity = [ExtMainSection new];
        sectionActivity.sectionTitle = @"Activity";
        sectionActivity.items = @[@"Activity Smoothly",
                                  @"Activity Slowly"];
        
        [_dataSource addObject:sectionActivity];
        
        sectionActivity = [ExtMainSection new];
        sectionActivity.sectionTitle = @"Test GestureRecognizer";
        sectionActivity.items = @[@"remove pair in action"];
        
        [_dataSource addObject:sectionActivity];
        
        sectionActivity = [ExtMainSection new];
        sectionActivity.sectionTitle = @"Bugfix";
        sectionActivity.items = @[@"simulate bugs"];
        
        [_dataSource addObject:sectionActivity];
        
        _tableView.delegate     = self;
        _tableView.dataSource   = self;
    }
    
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"Extensions";
    [self.view addSubview:self.tableView];
    
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.view);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark -UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    id vc;

    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            vc = [[ExtASIHttpRequestViewController alloc] init];
        } else if (indexPath.row == 1) {
            vc = [[ExtNSURLConnectionViewController alloc] init];
        } else if (indexPath.row == 2) {
            vc = [[ExtNSURLSessionViewController alloc] init];
        } else if (indexPath.row == 3) {
            vc = [[ExtWebViewViewController alloc] init];
        }
    } else if (indexPath.section == 1) {
        if (indexPath.row == 0) {//smoothly
            vc = [[ExtSmoothlyViewController alloc] init];
        } else {//slowly
            vc = [[ExtSlowlyViewController alloc] init];
        }
    } else if (indexPath.section == 2) {
        if (indexPath.row == 0) {
            vc = [[ExtRemovePairInActionViewController alloc] init];
        }
    } else if (indexPath.section == 3) {
        if (indexPath.row == 0) {
            vc = [[ExtBugfixMainViewController alloc] init];
        }
    }
    
    if (vc) {
        [self.navigationController pushViewController:vc animated:YES];
    }
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark -UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.dataSource.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataSource[section].items.count;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return self.dataSource[section].sectionTitle;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    
    cell.textLabel.text = self.dataSource[indexPath.section].items[indexPath.row];
    
    return cell;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
