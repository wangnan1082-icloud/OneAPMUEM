//
//  ExtRemovePairInActionViewController.h
//  OneAPMDemoTest
//
//  Created by 马杰亮 on 04/08/2017.
//  Copyright © 2017 Jun Li. All rights reserved.
//

#import "ExtBaseActivityViewController.h"

@interface ExtRemovePairInActionViewController : ExtBaseActivityViewController

@end
