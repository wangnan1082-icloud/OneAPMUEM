//
//  ExtBaseActivityViewController.h
//  OneAPMDemoTest
//
//  Created by JieLiang Ma on 9/1/16.
//  Copyright © 2016 Jun Li. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ExtBaseViewController.h"

@interface ExtBaseActivityViewController : ExtBaseViewController

@end
