//
//  ExtBaseActivityViewController.m
//  OneAPMDemoTest
//
//  Created by JieLiang Ma on 9/1/16.
//  Copyright © 2016 Jun Li. All rights reserved.
//

#import "ExtBaseActivityViewController.h"

#import <objc/runtime.h>

@interface ExtBaseActivityViewController ()
@end

@implementation ExtBaseActivityViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self runHeavyTaskInBackground];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self runHeavyTaskInBackground];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    [self runHeavyTaskInBackground];
}

- (void)runHeavyTaskInBackground {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        id image __unused = [[UIImage alloc] initWithData:[[NSData alloc] init]];
    });
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
