//
//  ExtASIHttpRequestViewController.h
//  OneAPMDemoTest
//
//  Created by 马杰亮 on 14/11/2017.
//  Copyright © 2017 Jun Li. All rights reserved.
//

#import "ExtHttpRequestViewController.h"

@interface ExtASIHttpRequestViewController : ExtHttpRequestViewController

@end
