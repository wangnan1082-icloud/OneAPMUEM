//
//  ExtASIHttpRequestViewController.m
//  OneAPMDemoTest
//
//  Created by 马杰亮 on 14/11/2017.
//  Copyright © 2017 Jun Li. All rights reserved.
//

#import "ExtASIHttpRequestViewController.h"

#import <ASIHTTPRequest/ASIHTTPRequest.h>

@interface ExtASIHttpRequestViewController ()

@end

@implementation ExtASIHttpRequestViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.title = @"ASI";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)doHttpRequest {
    [super doHttpRequest];

    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:[self url]];
    __weak ASIHTTPRequest *weakRequest = request;

    [request setCompletionBlock:^{
        dispatch_async(dispatch_get_main_queue(), ^{
            if (weakRequest.error) {
                self.textView.text = weakRequest.error.description;
            } else {
                self.textView.text =
                [[NSString alloc] initWithData:weakRequest.responseData
                                      encoding:NSUTF8StringEncoding];
            }
        });
    }];

    [request startAsynchronous];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
