//
//  ExtNSURLConnectionViewController.m
//  OneAPMDemoTest
//
//  Created by 马杰亮 on 14/11/2017.
//  Copyright © 2017 Jun Li. All rights reserved.
//

#import "ExtNSURLConnectionViewController.h"

@interface ExtNSURLConnectionViewController ()

@end

@implementation ExtNSURLConnectionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"NSURLConnection";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)doHttpRequest {
    [super doHttpRequest];

    NSURLRequest *request = [NSURLRequest requestWithURL:self.url];
    NSOperationQueue *queue = [[NSOperationQueue alloc] init];
    [NSURLConnection sendAsynchronousRequest:request queue:queue completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (connectionError) {
                self.textView.text = connectionError.description;
            } else {
                self.textView.text =
                [[NSString alloc] initWithData:data
                                      encoding:NSUTF8StringEncoding];
            }
        });
    }];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
