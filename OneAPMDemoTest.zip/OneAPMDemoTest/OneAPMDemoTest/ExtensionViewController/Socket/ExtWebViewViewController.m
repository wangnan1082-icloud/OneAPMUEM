//
//  ExtWebViewViewController.m
//  OneAPMDemoTest
//
//  Created by 马杰亮 on 14/11/2017.
//  Copyright © 2017 Jun Li. All rights reserved.
//

#import "ExtWebViewViewController.h"

@interface ExtWebViewViewController () {
    UIWebView *_webView;
    UITextField *_textField;
}

@end

@implementation ExtWebViewViewController

- (instancetype)init {
    if (self = [super init]) {
        _webView = [[UIWebView alloc] init];
        _webView.scalesPageToFit = YES;

        _textField = [[UITextField alloc] init];
        _textField.borderStyle = UITextBorderStyleRoundedRect;
        _textField.keyboardType = UIKeyboardTypeURL;
        _textField.text = @"https://";
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"WebView";
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    [button setTitle:@"go" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(go) forControlEvents:UIControlEventTouchUpInside];
    [button setContentHuggingPriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisHorizontal];

    [self.view addSubview:button];
    [self.view addSubview:_textField];
    [self.view addSubview:_webView];

    [_textField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).with.offset(64);
        make.left.equalTo(self.view);
        make.right.equalTo(button.mas_left);
        make.height.equalTo(@32);
    }];
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).with.offset(64);
        make.right.equalTo(self.view);
        make.height.equalTo(@32);
    }];
    [_webView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.and.bottom.equalTo(self.view);
        make.top.equalTo(_textField.mas_bottom);
    }];

    RAC(button, enabled) = [RACSignal combineLatest:@[_textField.rac_textSignal] reduce:^(NSString *urlString) {
        NSURL *url = [NSURL URLWithString:urlString];
        return @(url && url.scheme && url.host);
    }];
}

- (void)go {
    [_textField resignFirstResponder];
    [_webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:_textField.text]]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation

 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
