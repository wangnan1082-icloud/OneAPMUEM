//
//  ExtHttpRequestViewController.h
//  OneAPMDemoTest
//
//  Created by 马杰亮 on 14/11/2017.
//  Copyright © 2017 Jun Li. All rights reserved.
//

#import "ExtBaseActivityViewController.h"

@interface ExtHttpRequestViewController : ExtBaseActivityViewController

@property (nonatomic, strong) UITextField *textField;
@property (nonatomic, strong) UITextView *textView;

- (void)doHttpRequest;
- (NSURL *)url;

@end
