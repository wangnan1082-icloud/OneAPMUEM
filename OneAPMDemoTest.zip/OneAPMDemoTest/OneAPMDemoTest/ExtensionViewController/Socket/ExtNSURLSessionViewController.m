//
//  ExtNSURLSessionViewController.m
//  OneAPMDemoTest
//
//  Created by 马杰亮 on 14/11/2017.
//  Copyright © 2017 Jun Li. All rights reserved.
//

#import "ExtNSURLSessionViewController.h"

@interface ExtNSURLSessionViewController ()

@end

@implementation ExtNSURLSessionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"NSURLSession";
}

- (void)doHttpRequest {
    [super doHttpRequest];

    NSURLSessionTask *task = [[NSURLSession sharedSession] dataTaskWithURL:self.url completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                self.textView.text = error.description;
            } else {
                self.textView.text =
                [[NSString alloc] initWithData:data
                                      encoding:NSUTF8StringEncoding];
            }
        });
    }];
    [task resume];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
