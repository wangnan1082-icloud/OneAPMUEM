//
//  ExtHttpRequestViewController.m
//  OneAPMDemoTest
//
//  Created by 马杰亮 on 14/11/2017.
//  Copyright © 2017 Jun Li. All rights reserved.
//

#import "ExtHttpRequestViewController.h"

@interface ExtHttpRequestViewController ()

@end

@implementation ExtHttpRequestViewController

- (instancetype)init {
    if (self = [super init]) {
        _textField = [[UITextField alloc] init];
        _textField.borderStyle = UITextBorderStyleRoundedRect;
        _textField.keyboardType = UIKeyboardTypeURL;
        _textField.text = @"https://";

        _textView = [[UITextView alloc] init];
        _textView.textColor = UIColor.blackColor;
        _textView.font = [UIFont systemFontOfSize:14];
        _textView.editable = NO;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    [button setTitle:@"Request" forState:UIControlStateNormal];
    [button setContentHuggingPriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisHorizontal];
    [button addTarget:self action:@selector(doHttpRequest) forControlEvents:UIControlEventTouchUpInside];

    [self.view addSubview:self.textView];
    [self.view addSubview:self.textField];
    [self.view addSubview:button];

    [_textField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).with.offset(64);
        make.left.equalTo(self.view);
        make.right.equalTo(button.mas_left);
        make.height.equalTo(@32);
    }];
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.textField.mas_top);
        make.right.equalTo(self.view);
        make.height.equalTo(@32);
    }];
    [self.textView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.and.bottom.equalTo(self.view);
        make.top.equalTo(self.textField.mas_bottom);
    }];

    RAC(button, enabled) = [RACSignal combineLatest:@[self.textField.rac_textSignal] reduce:^id(NSString *urlString){
        NSURL *url = [NSURL URLWithString:urlString];
        return @(url && url.scheme && url.host);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSURL *)url {
    return [NSURL URLWithString:self.textField.text];
}

- (void)doHttpRequest {
    [self.textField resignFirstResponder];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
