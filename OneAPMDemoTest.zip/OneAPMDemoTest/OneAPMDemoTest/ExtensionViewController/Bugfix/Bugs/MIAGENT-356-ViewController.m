//
//  MIAGENT-356-ViewController.m
//  OneAPMDemoTest
//
//  Created by 马杰亮 on 17/10/2017.
//  Copyright © 2017 Jun Li. All rights reserved.
//

#import "MIAGENT-356-ViewController.h"

@interface DelegateProxy : NSProxy
- (instancetype)initWithDelegate:(id <UIAlertViewDelegate>)delegate;
@end

@implementation DelegateProxy {
    __weak id<UIAlertViewDelegate> _delegate;
}

- (instancetype)initWithDelegate:(id<UIAlertViewDelegate>)delegate {
    if (self) {
        _delegate = delegate;
    }
    return self;
}

- (BOOL)respondsToSelector:(SEL)aSelector {
    return [_delegate respondsToSelector:aSelector];
}

- (NSMethodSignature *)methodSignatureForSelector:(SEL)sel {
    id delegate = _delegate;
    return [delegate methodSignatureForSelector:sel];
}

- (void)forwardInvocation:(NSInvocation *)invocation {
    [invocation invokeWithTarget:_delegate];
}

@end

@interface MIAGENT_356_ViewController () <UIAlertViewDelegate>
@property (nonatomic, strong) DelegateProxy *proxy;
@end

@implementation MIAGENT_356_ViewController

- (instancetype)init {
    if (self = [super init]) {
        _proxy = [[DelegateProxy alloc] initWithDelegate:self];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIButton *button = [[UIButton alloc] init];
    
    [button setTitle:@"Alert" forState:UIControlStateNormal];
    [button setTitleColor:UIColor.blueColor forState:UIControlStateNormal];
    [button addTarget:self action:@selector(buttonSelector:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:button];
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.view);
        make.top.equalTo(self.view).with.offset(64 + 20);
    }];
}

- (void)buttonSelector:(UIButton *)button {
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"title" message:@"message" delegate:self.proxy cancelButtonTitle:@"cancel" otherButtonTitles:@"other", nil];
    
    [alertView show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    NSLog(@"alertView: %d", (int)buttonIndex);
}

@end
