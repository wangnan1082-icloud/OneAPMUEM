//
//  ViewController.m
//   OneAPMDemoTest
//


#import "ViewController.h"
#import "testview.h"
#import "MasterViewController.h"
#import "JSONMethodsViewController.h"
#import "ExtMainViewController.h"
#import "SetSwitch/SetMouduleSwitch.h"
#import <objc/message.h>

@interface ViewController () <UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UIButton *crashBtn;
@property (weak, nonatomic) IBOutlet UIButton *arrayCrashBtn;
@property (weak, nonatomic) IBOutlet UIButton *dicCrashBtn;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - IBAction

- (IBAction)toCrashStoryBoard:(id)sender {
    
    UIStoryboard *secondStoryBoard = [UIStoryboard storyboardWithName:@"CrashStoryboard" bundle:nil];
    UIViewController* test2obj = [secondStoryBoard instantiateViewControllerWithIdentifier:@"CRLMasterViewController"];  //test2viewcontroller的StoryboardId
    [self.navigationController pushViewController:test2obj animated:YES];
}

//数据库
- (IBAction)toDBDemo:(id)sender
{
    testview *coreDataDemo = [[testview alloc] init];
    [self.navigationController pushViewController:coreDataDemo animated:YES];
}

// SDImage
- (IBAction)toSDWebImage:(id)sender
{
    MasterViewController *sd = [[MasterViewController alloc] initWithNibName:@"MasterViewController" bundle:nil];
    
    [self.navigationController pushViewController:sd animated:YES];
}

- (IBAction)btnCrash:(id)sender {
    
    // Crash测试
    NSMutableArray *array = [[NSMutableArray alloc] initWithArray:@[@"AA",@"BB"]];
    NSLog(@"%@",array[2]);
}

//Json
- (IBAction)toJsonVC:(id)sender
{    
    JSONMethodsViewController * jsonVC = [[JSONMethodsViewController alloc] initWithNibName:@"JSONMethodsViewController" bundle:nil];
    [self.navigationController pushViewController:jsonVC animated:YES];
}
- (IBAction)dicCrash:(id)sender {
    
    NSString *str;
    NSDictionary *dic __unused = @{@"key":str};
}

- (IBAction)touchView:(id)sender {
    [self.view endEditing:YES];
}

- (IBAction)toExtension:(id)sender {
    @autoreleasepool {
        id vc = [[ExtMainViewController alloc] init];
        
        [self.navigationController pushViewController:vc animated:YES];
    }
}

@end
