//
//  ActionAnalysisViewController.m
//  OneAPMDemoTest
//
//  Created by yuxr on 16/4/12.
//  Copyright © 2016年 Jun Li. All rights reserved.
//

#import "ActionAnalysisViewController.h"

@interface ActionAnalysisViewController ()
@property (weak, nonatomic) IBOutlet UITextField *userIdTF;
@property (weak, nonatomic) IBOutlet UITextField *sexTF;
@property (weak, nonatomic) IBOutlet UITextField *ageTF;
@property (weak, nonatomic) IBOutlet UILabel *warningLbl;
@property (weak, nonatomic) IBOutlet UIButton *trackTimerBtn;

@end

@implementation ActionAnalysisViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationItem.title = @"控制台";
#ifdef KEnableActionAnalyticsTest
    // 进入行为分析页面
    [OneAPMActionAnalytics track:@"APM_AnalysisVCDidLoad"];
    
    [OneAPMActionAnalytics registerSuperProperties:@{@"APM_userLevel" : @"SuperVIP",
                                                     @"APM_userProfession" : @"Doctor"}];
#else
    _warningLbl.text = @"若要测试行为分析，请在PCH文件启用KEnableActionAnalyticsTest宏，并使用带有行为分析的framework";
#endif
    
    [_trackTimerBtn setTitle:@"trackTimer" forState:UIControlStateNormal];
    [_trackTimerBtn setTitle:@"stopTrackTimer" forState:UIControlStateSelected];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
#ifdef KEnableActionAnalyticsTest
    [OneAPMActionAnalytics track:@"APM_AnalysisVCDidDisappear"];
    
    [OneAPMActionAnalytics clearTrackTimer];
#endif
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}

- (IBAction)signUpBtnClick:(id)sender {
#ifdef KEnableActionAnalyticsTest
    [OneAPMActionAnalytics track:@"APM_signup"];
    [OneAPMActionAnalytics trackSignUp:_userIdTF.text withProperties:@{@"APM_signuptime" : [NSNumber numberWithDouble:[[NSDate date] timeIntervalSince1970]],
                                                                           @"APM_signupcity" : @"Beijing"}];
#endif
}

- (IBAction)registerPropertyBtnClick:(id)sender {
    [_ageTF.text integerValue];
#ifdef KEnableActionAnalyticsTest
    [OneAPMActionAnalytics registerSuperProperties:@{@"APM_userSex" : _sexTF.text,
                                                     @"APM_userAge" : [NSNumber numberWithInteger:[_ageTF.text integerValue]]}];
#endif
}

- (IBAction)unregisterPropertyBtnClick:(id)sender {
#ifdef KEnableActionAnalyticsTest
    [OneAPMActionAnalytics unregisterSuperProperty:@"APM_userSex"];
    [OneAPMActionAnalytics unregisterSuperProperty:@"APM_userAge"];
#endif
}

- (IBAction)clearPropertyBtnClick:(id)sender {
#ifdef KEnableActionAnalyticsTest
    [OneAPMActionAnalytics clearSuperProperties];
#endif
}

- (IBAction)deleteUserBtnClick:(id)sender {
#ifdef KEnableActionAnalyticsTest
    [OneAPMActionAnalytics deleteUser];
#endif
}

- (IBAction)sendDataBtnClick:(id)sender {
#ifdef KEnableActionAnalyticsTest
    [OneAPMActionAnalytics flush];
#endif
}

- (IBAction)trackTimerBtnClick:(id)sender {
    UIButton *btn = (UIButton *)sender;
    btn.selected = !btn.selected;
#ifdef KEnableActionAnalyticsTest
    if (btn.selected) {
        [OneAPMActionAnalytics trackTimer:@"APM_trackTimer"];
    } else {
        [OneAPMActionAnalytics track:@"APM_trackTimer"];
    }
#endif
}

@end
