//
//  main.m
//  OneAPMDemoTest
//
//  Created by JunLee on 15/12/14.
//  Copyright © 2015年 Jun Li. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import <OneAPMUEM/OneAPM.h>
#import <stdio.h>

int main(int argc, char * argv[]) {
    @autoreleasepool {
        
        [OneAPM setPrintLog:YES];
        
        [OneAPM setUserName:@"OneAPM Demo"];
        [OneAPM setSearchKey:@"keywords"];
        [OneAPM setCustomInfo:@{@"key1" : @"value1",
                                @"key2" : @"value2"
                                }];
        
#warning 更新此处的 token 为开发者自己申请的值
        [OneAPM startWithApplicationToken:@"Your Token!!!"];
        
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
        
    }
}
